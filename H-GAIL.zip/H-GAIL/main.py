import gym
import torch
import torch.optim as optim
from collections import deque
import numpy as np

from model_hgail import Actor, Critic, LowDiscriminator, HighDiscriminator
from train_hgail import train_hgail, train_high_discrim

# Hyperparameters
args = {
    'gamma': 0.99,
    'lamda': 0.98,
    'hidden_size': 100,
    'learning_rate': 3e-4,
    'l2_rate': 1e-3,
    'clip_param': 0.2,
    'discrim_update_num': 2,
    'actor_critic_update_num': 10,
    'total_sample_size': 2048,
    'batch_size': 64,
    'max_iter_num': 4000,
    'seed': 500,
}

# Initialize environment
env = gym.make('CartPole-v1')
env.seed(args['seed'])
torch.manual_seed(args['seed'])

num_inputs = env.observation_space.shape[0]
num_actions = env.action_space.n  # Note that CartPole has a discrete action space

# Initialize models and optimizers
actor = Actor(num_inputs, num_actions, args)
critic = Critic(num_inputs, args)
low_discrim = LowDiscriminator(num_inputs + num_actions, args)
high_discrim = HighDiscriminator(num_inputs, args)

actor_optim = optim.Adam(actor.parameters(), lr=args['learning_rate'])
critic_optim = optim.Adam(critic.parameters(), lr=args['learning_rate'], weight_decay=args['l2_rate'])
discrim_optim = optim.Adam(list(low_discrim.parameters()) + list(high_discrim.parameters()), lr=args['learning_rate'])

# Training loop
for iter in range(args['max_iter_num']):
    memory = deque()
    steps = 0
    scores = []

    while steps < args['total_sample_size']:
        state = env.reset()
        score = 0

        for _ in range(10000):
            action_prob = actor(torch.Tensor(state).unsqueeze(0))
            action = torch.multinomial(action_prob, 1).item()
            next_state, reward, done, _ = env.step(action)

            irl_reward = train_hgail.get_reward(low_discrim, high_discrim, state, action)

            if done:
                mask = 0
            else:
                mask = 1

            memory.append([state, action, irl_reward, mask])
            state = next_state
            score += reward

            if done:
                break

            steps += 1

        scores.append(score)

    # Update models
    train_hgail(actor, critic, low_discrim, high_discrim, memory, actor_optim, critic_optim, discrim_optim, args)
    train_high_discrim(high_discrim, memory, discrim_optim, args)

    # Logging
    score_avg = np.mean(scores)
    print(f"Iteration {iter}: average score is {score_avg}")

# Save models
torch.save({
    'actor': actor.state_dict(),
    'critic': critic.state_dict(),
    'low_discrim': low_discrim.state_dict(),
    'high_discrim': high_discrim.state_dict(),
}, 'hgail_cartpole.pth')
