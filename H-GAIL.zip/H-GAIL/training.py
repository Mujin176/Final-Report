import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque

def train_high_discrim(high_discrim, memory, discrim_optim, demonstrations, args):
    states, actions, _, _ = zip(*memory)
    states = torch.Tensor(states)
    actions = torch.Tensor(actions)

    criterion = nn.BCELoss()

    learner = high_discrim(torch.cat([states, actions], dim=1))
    demonstrations = torch.Tensor(demonstrations)
    expert = high_discrim(demonstrations)

    discrim_loss = criterion(learner, torch.ones((states.shape[0], 1))) + \
                   criterion(expert, torch.zeros((demonstrations.shape[0], 1)))

    discrim_optim.zero_grad()
    discrim_loss.backward()
    discrim_optim.step()

    expert_acc = ((high_discrim(demonstrations) < 0.5).float()).mean()
    learner_acc = ((high_discrim(torch.cat([states, actions], dim=1)) > 0.5).float()).mean()

    return expert_acc, learner_acc

def train_hgail(actor, critic, low_discrim, high_discrim, memory, actor_optim, critic_optim, discrim_optim, args):
    states, actions, rewards, masks = zip(*memory)
    states = torch.Tensor(states)
    actions = torch.Tensor(actions)
    rewards = torch.Tensor(rewards)
    masks = torch.Tensor(masks)

    # Train High Discriminator
    expert_acc, learner_acc = train_high_discrim(high_discrim, memory, discrim_optim, demonstrations, args)

    # Train Low Discriminator (similar to your original train_discrim)
    # ...

    # Train Actor-Critic (similar to your original train_actor_critic)
    # ...

    return expert_acc, learner_acc

# Example usage
if __name__ == "__main__":
    args = {
        'hidden_size': 100,
        'learning_rate': 3e-4,
        'gamma': 0.99,
        'lamda': 0.98,
        'clip_param': 0.2,
        'discrim_update_num': 2,
        'actor_critic_update_num': 10,
        'batch_size': 64,
        'total_sample_size': 2048,
        'max_iter_num': 4000,
        'suspend_accu_exp': 0.8,
        'suspend_accu_gen': 0.8
    }

    env = gym.make('CartPole-v1')
    num_inputs = env.observation_space.shape[0]
    num_actions = env.action_space.n  # Assuming discrete action space

    actor = Actor(num_inputs, num_actions, args)
    critic = Critic(num_inputs, args)
    low_discrim = LowDiscriminator(num_inputs + num_actions, args)
    high_discrim = HighDiscriminator(num_inputs + num_actions, args)

    actor_optim = optim.Adam(actor.parameters(), lr=args['learning_rate'])
    critic_optim = optim.Adam(critic.parameters(), lr=args['learning_rate'])
    discrim_optim = optim.Adam(list(low_discrim.parameters()) + list(high_discrim.parameters()), lr=args['learning_rate'])

    memory = deque()
    # Assume demonstrations is a list of state-action pairs from expert
    demonstrations = []

    expert_acc, learner_acc = train_hgail(actor, critic, low_discrim, high_discrim, memory, actor_optim, critic_optim, discrim_optim, args)
    print("Expert: %.2f%% | Learner: %.2f%%" % (expert_acc * 100, learner_acc * 100))
