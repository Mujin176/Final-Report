# main_all.py
import os
import gym
import torch
import argparse
from model_hgail import Actor, Critic  # Make sure to import from your H-GAIL model file

def get_action(mu, std):
    action = torch.normal(mu, std)
    action = action.data.numpy()
    return action

def test_environment(env_name, model_path, num_episodes=5):
    env = gym.make(env_name)
    env.seed(500)
    torch.manual_seed(500)

    num_inputs = env.observation_space.shape[0]
    num_actions = env.action_space.n if isinstance(env.action_space, gym.spaces.Discrete) else env.action_space.shape[0]

    print(f"Testing {env_name}")
    print("State size: ", num_inputs)
    print("Action size: ", num_actions)

    actor = Actor(num_inputs, num_actions)
    critic = Critic(num_inputs)

    pretrained_model = torch.load(model_path)
    actor.load_state_dict(pretrained_model['actor'])
    critic.load_state_dict(pretrained_model['critic'])

    actor.eval(), critic.eval()

    for episode in range(num_episodes):
        state = env.reset()
        score = 0

        for _ in range(10000):
            env.render()
            mu, std = actor(torch.Tensor(state).unsqueeze(0))
            action = get_action(mu, std)[0]
            next_state, reward, done, _ = env.step(action)
            state = next_state
            score += reward

            if done:
                print(f"Episode {episode+1}, Cumulative reward: {score}")
                break

    env.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--num_episodes', type=int, default=5,
                        help='number of episodes to play for each environment')
    args = parser.parse_args()

    envs = [
        'CartPole-v1',
        'Acrobot-v1',
        'MountainCar-v0',
        'HalfCheetah-v2',
        'Hopper-v2',
        'Walker2d-v2',
        'Ant-v2',
        'Humanoid-v2',
        'Reacher-v2'
    ]

    for env_name in envs:
        model_path = os.path.join(os.getcwd(), 'save_model', f'hgail_{env_name}.pth')
        test_environment(env_name, model_path, args.num_episodes)
