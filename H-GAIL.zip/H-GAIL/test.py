import os
import gym
import torch
import argparse
from model_hgail import Actor, Critic  # Make sure to import from your H-GAIL model file

def get_action(mu, std):
    action = torch.normal(mu, std)
    action = action.data.numpy()
    return action

parser = argparse.ArgumentParser()
parser.add_argument('--iter', type=int, default=5,
                    help='number of episodes to play')
parser.add_argument("--load_model", type=str, default='hgail_cartpole.pth',
                     help="filename of the pretrained model")
args = parser.parse_args()

if __name__ == "__main__":
    env = gym.make('CartPole-v1')
    env.seed(500)
    torch.manual_seed(500)

    num_inputs = env.observation_space.shape[0]
    num_actions = env.action_space.n  # Note: CartPole uses a discrete action space

    print("state size: ", num_inputs)
    print("action size: ", num_actions)

    actor = Actor(num_inputs, num_actions)
    critic = Critic(num_inputs)

    if args.load_model is not None:
        pretrained_model_path = os.path.join(os.getcwd(), 'save_model', str(args.load_model))
        pretrained_model = torch.load(pretrained_model_path)

        actor.load_state_dict(pretrained_model['actor'])
        critic.load_state_dict(pretrained_model['critic'])

        print("Loaded pretrained model.")

    else:
        print("No pretrained model specified. Exiting.")
        exit()

    actor.eval(), critic.eval()

    for episode in range(args.iter):
        state = env.reset()
        score = 0

        for _ in range(10000):  # Run for a max of 10k to avoid infinite loop
            env.render()

            mu, std = actor(torch.Tensor(state).unsqueeze(0))
            action = get_action(mu, std)[0]

            next_state, reward, done, _ = env.step(action)
            state = next_state
            score += reward

            if done:
                print(f"Episode {episode+1}, Cumulative reward: {score}")
                break

    env.close()
